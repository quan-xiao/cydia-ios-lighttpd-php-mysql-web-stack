var JQUERY_THEME = WB_URL+'/include/jquery';

$(document).ready(function() {
        $.insert(JQUERY_THEME+'/jquery-ui.css');
        $.insert(JQUERY_THEME+'/jquery-ui-min.js');
});
