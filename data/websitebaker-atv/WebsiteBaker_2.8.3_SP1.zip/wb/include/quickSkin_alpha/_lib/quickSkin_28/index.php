<?php
/**
 *
 * @category        Security
 * @package         FolderProtectFile
 * @author          WebsiteBaker Project
 * @copyright       2009-2011, Website Baker Org. e.V.
 * @link            http://www.websitebaker2.org/
 * @license         http://www.gnu.org/licenses/gpl.html
 * @platform        WebsiteBaker 2.8.x
 * @requirements    PHP 5.2.2 and higher
 * @version         $Id: index.php 1546 2011-12-18 20:00:32Z Luisehahne $
 * @filesource      $HeadURL: svn://isteam.dynxs.de/wb_svn/wb280/tags/2.8.3/wb/include/quickSkin_alpha/_lib/quickSkin_28/index.php $
 * @lastmodified    $Date: 2011-12-18 21:00:32 +0100 (So, 18. Dez 2011) $
 *
 */

header('HTTP/1.1 301 Moved Permanently');
header("Location: ../../index.php");

