<?php
/**
 *
 * @category        modules
 * @package         captcha_control
 * @author          Independend-Software-Team
 * @author          WebsiteBaker Project
 * @copyright       2004-2009, Ryan Djurovich
 * @copyright       2009-2011, Website Baker Org. e.V.
 * @link            http://www.websitebaker2.org/
 * @license         http://www.gnu.org/licenses/gpl.html
 * @platform        WebsiteBaker 2.8.x
 * @requirements    PHP 5.2.2 and higher
 * @version         $Id: index.php 1477 2011-07-21 02:47:28Z Luisehahne $
 * @filesource      $HeadURL: svn://isteam.dynxs.de/wb_svn/wb280/tags/2.8.3/wb/modules/captcha_control/index.php $
 * @lastmodified    $Date: 2011-07-21 04:47:28 +0200 (Do, 21. Jul 2011) $
 *
 */

header('Location: ../index.php');
