The folder admin/images isn't needed for WB 2.8. anymore.

It remains only to keep backward compatibility to old modules
wich make use of the images from this folder.

Modules should be adapted as soon as possible to use images
from the backend themes instead.

If you are shure you have only Modules wich uses images from
backend themes, this folder can be deleted.