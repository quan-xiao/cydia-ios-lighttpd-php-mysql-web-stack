plugin.wt_spamshield {
	enable.standardMailform = 1
}