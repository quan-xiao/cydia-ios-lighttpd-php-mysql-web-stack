// Remove targets
styles.content.links.extTarget =
