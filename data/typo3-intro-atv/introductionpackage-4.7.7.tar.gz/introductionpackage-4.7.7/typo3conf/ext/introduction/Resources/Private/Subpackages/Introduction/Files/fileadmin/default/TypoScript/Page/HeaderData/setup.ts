page.headerData {
	10 = TEMPLATE
	10 {
		template =< plugin.tx_automaketemplate_pi1
		workOnSubpart = DOCUMENT_HEADER
	}
	20 = TEXT
	20.value = <meta name="robots" content="noindex,follow" />
}