lib.contentleft = COA

# Insert the content from the left column into lib.contentleft
lib.contentleft {
	20 < styles.content.getLeft
}