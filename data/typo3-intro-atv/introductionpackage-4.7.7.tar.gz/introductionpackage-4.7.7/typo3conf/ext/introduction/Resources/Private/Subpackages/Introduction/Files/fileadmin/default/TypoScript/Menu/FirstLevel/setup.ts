# Start with copying our default menu configuration so we don't have to repeat our selves (except in the explanation, didn't I already mention this?) ;-)
menu.firstlevel < menu
menu.firstlevel {
	# Since this is the top-level menu, we start this menu at the root level of the website
	entryLevel = 0
}
