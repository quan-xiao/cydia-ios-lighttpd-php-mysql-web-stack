This extension is part of the Introduction Package and handles the
automatic install process by hooking into the 1-2-3 installer.

Find the latest TYPO3 packages here
	http://typo3.org/download/packages/

This package is maintained at these resources
	http://git.typo3.org/TYPO3v4/Distributions/Introduction.git
	http://forge.typo3.org/projects/extension-introduction